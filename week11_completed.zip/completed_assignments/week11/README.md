# Week 11 — Multi-page Gapminder Dashboard

Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app contains three question-led pages following summary → trend → detail.
It uses a cached shared loader, `st.session_state`, `st.tabs()`, and comments that
name the colour type used by every chart.
