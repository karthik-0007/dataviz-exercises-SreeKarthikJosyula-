import os
import sys

import plotly.express as px
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from utils import load_gapminder


df = load_gapminder()
st.title("How do countries compare today?")
st.caption("Bubble size = population | Colour = continent")

years = sorted(df["year"].unique())
selected_year = st.selectbox("Year", years, index=len(years) - 1)
df_y = df[df["year"] == selected_year].copy()

c1, c2, c3 = st.columns(3)
c1.metric("Countries", len(df_y))
c2.metric("Average life expectancy", f"{df_y['lifeExp'].mean():.1f} years")
c3.metric(
    "Highest GDP per capita",
    df_y.loc[df_y["gdpPercap"].idxmax(), "country"],
    f"${df_y['gdpPercap'].max():,.0f}",
)

st.divider()

# BBD CATEGORICAL colour: distinct hues represent unordered continents.
fig = px.scatter(
    df_y,
    x="gdpPercap",
    y="lifeExp",
    size="pop",
    color="continent",
    hover_name="country",
    log_x=True,
    size_max=55,
    labels={
        "gdpPercap": "GDP per capita (log scale)",
        "lifeExp": "Life expectancy (years)",
        "continent": "Continent",
    },
    title=f"Wealthier countries generally live longer, with diminishing returns ({selected_year})",
    height=680,
)
fig.update_layout(
    plot_bgcolor="white",
    paper_bgcolor="white",
    font=dict(family="Arial", size=12),
    xaxis=dict(gridcolor="#EEEEEE"),
    yaxis=dict(gridcolor="#EEEEEE"),
    legend=dict(orientation="h", y=1.08),
)
fig.update_traces(marker=dict(opacity=0.75, line=dict(width=0.5, color="white")))
st.plotly_chart(fig, use_container_width=True)
