import os
import sys

import plotly.express as px
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from utils import load_gapminder


df = load_gapminder()
latest_year = int(df["year"].max())
df_latest = df[df["year"] == latest_year].copy()

st.title("What explains the differences between countries?")
st.caption("Summary → trend → one-country detail")

countries = sorted(df_latest["country"].unique().tolist())
if "highlight_country" not in st.session_state:
    st.session_state.highlight_country = "China" if "China" in countries else countries[0]
else:
    st.session_state.highlight_country = st.session_state.highlight_country

if st.session_state.highlight_country not in countries:
    st.session_state.highlight_country = countries[0]

st.selectbox("Highlight a country", countries, key="highlight_country")
highlight_country = st.session_state.highlight_country
country_row = df_latest[df_latest["country"] == highlight_country].iloc[0]
highlight_continent = country_row["continent"]

k1, k2, k3 = st.columns(3)
k1.metric("Life expectancy", f"{country_row['lifeExp']:.1f} years")
k2.metric("GDP per capita", f"${country_row['gdpPercap']:,.0f}")
k3.metric("Population", f"{country_row['pop'] / 1_000_000:.1f} million")

st.divider()
tab1, tab2 = st.tabs(["GDP vs life expectancy", "Continental peers"])

with tab1:
    plot_df = df_latest.copy()
    plot_df["highlight"] = plot_df["country"].apply(
        lambda country: "Selected" if country == highlight_country else "Other"
    )
    plot_df["label"] = plot_df["country"].where(
        plot_df["country"] == highlight_country, ""
    )

    # BBD HIGHLIGHT colour: selected country is blue; all context points are grey.
    fig1 = px.scatter(
        plot_df,
        x="gdpPercap",
        y="lifeExp",
        color="highlight",
        text="label",
        hover_name="country",
        log_x=True,
        color_discrete_map={"Selected": "#2E75B6", "Other": "#B7B7B7"},
        category_orders={"highlight": ["Other", "Selected"]},
        labels={
            "gdpPercap": "GDP per capita (log scale)",
            "lifeExp": "Life expectancy (years)",
            "highlight": "",
        },
        title=f"{highlight_country} in the global wealth-and-health pattern ({latest_year})",
        height=600,
    )
    fig1.update_traces(
        marker=dict(size=9, opacity=0.85, line=dict(width=0)),
        textposition="top center",
    )
    fig1.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(family="Arial", size=12),
        showlegend=False,
        xaxis=dict(gridcolor="#EEEEEE"),
        yaxis=dict(gridcolor="#EEEEEE"),
    )
    st.plotly_chart(fig1, use_container_width=True)

with tab2:
    continent_df = (
        df_latest[df_latest["continent"] == highlight_continent]
        .sort_values("lifeExp")
        .copy()
    )
    continent_df["highlight"] = continent_df["country"].apply(
        lambda country: "Selected" if country == highlight_country else "Peer"
    )

    # BBD HIGHLIGHT colour: selected country is blue; continental peers are grey.
    fig2 = px.bar(
        continent_df,
        x="lifeExp",
        y="country",
        orientation="h",
        color="highlight",
        color_discrete_map={"Selected": "#2E75B6", "Peer": "#B7B7B7"},
        category_orders={"country": continent_df["country"].tolist()},
        labels={"lifeExp": "Life expectancy (years)", "country": "", "highlight": ""},
        title=f"{highlight_country} compared with {highlight_continent} peers ({latest_year})",
        height=max(500, 30 * len(continent_df)),
    )
    fig2.update_traces(marker_line_width=0)
    fig2.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        font=dict(family="Arial", size=12),
        showlegend=False,
        xaxis=dict(gridcolor="#EEEEEE", range=[0, continent_df["lifeExp"].max() * 1.1]),
        yaxis=dict(showgrid=False),
    )
    st.plotly_chart(fig2, use_container_width=True)
