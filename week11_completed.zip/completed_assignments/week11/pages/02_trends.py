import os
import sys

import plotly.express as px
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from utils import load_gapminder


df = load_gapminder()
st.title("How has global development changed over time?")

with st.sidebar:
    st.header("Trend filters")
    continent_options = sorted(df["continent"].unique().tolist())
    continents = st.multiselect(
        "Continents", continent_options, default=continent_options
    )
    metric = st.radio("Metric", ["Life expectancy", "GDP per capita"])

if not continents:
    st.warning("Select at least one continent.")
    st.stop()

y_col = "lifeExp" if metric == "Life expectancy" else "gdpPercap"
y_label = "Life expectancy (years)" if y_col == "lifeExp" else "GDP per capita"

avg = (
    df[df["continent"].isin(continents)]
    .groupby(["continent", "year"], as_index=False)[y_col]
    .mean()
)

st.caption(
    f"Showing {len(continents)} continents and {len(avg):,} continent-year observations."
)

# BBD CATEGORICAL colour: one distinct hue per unordered continent group.
fig = px.line(
    avg,
    x="year",
    y=y_col,
    color="continent",
    markers=True,
    labels={y_col: y_label, "year": "", "continent": "Continent"},
    title=f"Average {metric.lower()} has improved, but gains differ by continent",
    height=680,
)
fig.update_layout(
    plot_bgcolor="white",
    paper_bgcolor="white",
    font=dict(family="Arial", size=12),
    yaxis=dict(gridcolor="#EEEEEE"),
    xaxis=dict(showgrid=False),
    legend=dict(orientation="h", y=1.08),
)
st.plotly_chart(fig, use_container_width=True)
