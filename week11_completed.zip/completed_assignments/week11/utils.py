"""Shared data loading for every Week 11 page."""

import plotly.express as px
import streamlit as st


@st.cache_data
def load_gapminder():
    """Return a copy of Plotly's built-in Gapminder dataset."""
    return px.data.gapminder().copy()
