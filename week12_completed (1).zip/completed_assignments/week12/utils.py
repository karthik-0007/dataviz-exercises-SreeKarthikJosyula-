"""Shared data loading and persistent sidebar filters for Week 12."""

from __future__ import annotations

import math
from pathlib import Path

import pandas as pd
import streamlit as st


@st.cache_data
def load_data() -> tuple[pd.DataFrame, float]:
    script_dir = Path(__file__).resolve().parent
    candidates = [
        script_dir / "data" / "airbnb_london.csv",
        script_dir.parent / "data" / "airbnb_london.csv",
    ]
    path = next((candidate for candidate in candidates if candidate.exists()), None)
    if path is None:
        raise FileNotFoundError(
            "airbnb_london.csv was not found. Put it in week12/data/ or the repo data/ folder."
        )

    df = pd.read_csv(path)
    required = {"neighbourhood", "room_type", "price", "reviews_per_month"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")

    df = df.copy()
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["reviews_per_month"] = pd.to_numeric(
        df["reviews_per_month"], errors="coerce"
    )
    df = df.dropna(subset=["neighbourhood", "room_type", "price"])
    df["reviews_per_month"] = df["reviews_per_month"].fillna(0)

    p95 = float(df["price"].quantile(0.95))
    capped = df[df["price"] <= p95].copy()
    return capped, p95


def init_filters(df: pd.DataFrame) -> None:
    min_price = int(math.floor(df["price"].min()))
    max_price = int(math.ceil(df["price"].max()))
    defaults = {
        "flt_rooms": sorted(df["room_type"].unique().tolist()),
        "flt_hoods": sorted(df["neighbourhood"].unique().tolist()),
        "flt_price": (min_price, max_price),
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value
        else:
            st.session_state[key] = st.session_state[key]

    # Defensive guards in case the underlying dataset changes.
    st.session_state.flt_rooms = [
        value for value in st.session_state.flt_rooms if value in defaults["flt_rooms"]
    ]
    st.session_state.flt_hoods = [
        value for value in st.session_state.flt_hoods if value in defaults["flt_hoods"]
    ]
    low, high = st.session_state.flt_price
    st.session_state.flt_price = (
        max(min_price, int(low)),
        min(max_price, int(high)),
    )


def sidebar_filters(df: pd.DataFrame, p95: float) -> pd.DataFrame:
    init_filters(df)
    min_price = int(math.floor(df["price"].min()))
    max_price = int(math.ceil(df["price"].max()))

    with st.sidebar:
        st.header("🔎 Filters")
        st.multiselect(
            "Room type", sorted(df["room_type"].unique()), key="flt_rooms"
        )
        st.multiselect(
            "Neighbourhood",
            sorted(df["neighbourhood"].unique()),
            key="flt_hoods",
        )
        st.slider(
            "Price (£/night)",
            min_price,
            max_price,
            key="flt_price",
        )
        st.divider()
        st.caption(
            f"Prices capped at the 95th percentile (£{p95:.0f}) "
            "to remove extreme outliers."
        )

    filtered = df[
        df["room_type"].isin(st.session_state.flt_rooms)
        & df["neighbourhood"].isin(st.session_state.flt_hoods)
        & df["price"].between(*st.session_state.flt_price)
    ].copy()

    if filtered.empty:
        st.warning("No listings match the current filters.")
        st.stop()

    return filtered
