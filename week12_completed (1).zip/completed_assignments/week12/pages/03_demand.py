"""Demand drill-down page for the Week 12 assignment."""

import os
import sys

import plotly.express as px
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from utils import load_data, sidebar_filters


df, p95 = load_data()
filtered = sidebar_filters(df, p95)

st.title("Where is guest demand strongest?")
st.caption(
    "Reviews per month is used as a practical demand proxy. "
    "Choose a room type to compare neighbourhoods."
)

room_options = sorted(filtered["room_type"].dropna().unique().tolist())
preferred_room = "Entire home/apt" if "Entire home/apt" in room_options else room_options[0]

# Persisted page widget: initialise once, keep alive, and guard invalid values.
if "sel_room" not in st.session_state:
    st.session_state.sel_room = preferred_room
else:
    st.session_state.sel_room = st.session_state.sel_room

if st.session_state.sel_room not in room_options:
    st.session_state.sel_room = preferred_room

st.radio("Focus on a room type", room_options, key="sel_room", horizontal=True)
selected_room = st.session_state.sel_room
focus_df = filtered[filtered["room_type"] == selected_room].copy()

if focus_df.empty:
    st.warning("No listings remain for the selected room type.")
    st.stop()

market_median_reviews = filtered["reviews_per_month"].median()
room_median_reviews = focus_df["reviews_per_month"].median()
market_median_price = filtered["price"].median()
room_median_price = focus_df["price"].median()

k1, k2, k3 = st.columns(3)
k1.metric("Listings", f"{len(focus_df):,}")
k2.metric(
    "Median reviews/month",
    f"{room_median_reviews:.2f}",
    f"{room_median_reviews - market_median_reviews:+.2f} vs filtered market",
)
k3.metric(
    "Median price",
    f"£{room_median_price:.0f}/night",
    f"£{room_median_price - market_median_price:+.0f} vs filtered market",
)

st.divider()

# Aggregate the selected room type so the chart directly answers "where".
demand_by_hood = (
    focus_df.groupby("neighbourhood", as_index=False)
    .agg(
        listings=("price", "size"),
        median_price=("price", "median"),
        median_reviews_per_month=("reviews_per_month", "median"),
    )
    .sort_values("median_reviews_per_month", ascending=False)
)

# Avoid declaring a one-listing neighbourhood the winner when a better-supported
# comparison exists. Fall back to every neighbourhood if all groups are small.
eligible = demand_by_hood[demand_by_hood["listings"] >= 3]
leader_pool = eligible if not eligible.empty else demand_by_hood
leader_row = leader_pool.iloc[0]
leader = leader_row["neighbourhood"]
leader_demand = float(leader_row["median_reviews_per_month"])

demand_by_hood["highlight"] = demand_by_hood["neighbourhood"].apply(
    lambda neighbourhood: "Demand leader" if neighbourhood == leader else "Other neighbourhoods"
)

# BBD HIGHLIGHT colour: demand leader is blue; other neighbourhoods are grey.
# This is CVD-safe and does not rely on red/green differentiation.
fig = px.scatter(
    demand_by_hood,
    x="median_price",
    y="median_reviews_per_month",
    size="listings",
    color="highlight",
    hover_name="neighbourhood",
    hover_data={
        "listings": True,
        "median_price": ":.0f",
        "median_reviews_per_month": ":.2f",
        "highlight": False,
    },
    color_discrete_map={
        "Demand leader": "#2E75B6",
        "Other neighbourhoods": "#B7B7B7",
    },
    category_orders={"highlight": ["Other neighbourhoods", "Demand leader"]},
    labels={
        "median_price": "Median nightly price (£)",
        "median_reviews_per_month": "Median reviews per month",
        "highlight": "",
        "listings": "Listings",
    },
    title=(
        f"{leader} shows the strongest demand for {selected_room} "
        f"({leader_demand:.2f} median reviews/month)"
    ),
    size_max=55,
    height=620,
)
fig.update_layout(
    plot_bgcolor="white",
    paper_bgcolor="white",
    font=dict(family="Arial", size=12),
    xaxis=dict(gridcolor="#EEEEEE"),
    yaxis=dict(gridcolor="#EEEEEE"),
    legend=dict(orientation="h", y=1.08),
)
fig.update_traces(marker=dict(opacity=0.82, line=dict(width=0.5, color="white")))
st.plotly_chart(fig, use_container_width=True)

with st.expander("Show neighbourhood demand table"):
    st.dataframe(
        demand_by_hood[
            [
                "neighbourhood",
                "listings",
                "median_reviews_per_month",
                "median_price",
            ]
        ],
        use_container_width=True,
    )
