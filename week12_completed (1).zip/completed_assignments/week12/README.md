# Week 12 — London Airbnb Dashboard

Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

The provided first and second pages are retained. The completed third page is
registered in navigation, calls the shared persistent sidebar, keeps its room-type
widget alive with a guard, presents a three-KPI row, and uses a CVD-safe blue-vs-grey
highlight chart with an insight title.

The bundled CSV is a small schema-compatible dataset for testing. Replace it with
the course `airbnb_london.csv` if your instructor supplied a different file.
