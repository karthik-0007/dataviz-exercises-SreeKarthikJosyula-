"""Week 12 entry point. Run with: streamlit run app.py"""

import streamlit as st

st.set_page_config(
    page_title="London Airbnb Analytics",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Keep page-specific selections alive while their widgets are not rendered.
for key in ("sel_hood", "sel_room"):
    if key in st.session_state:
        st.session_state[key] = st.session_state[key]

pg = st.navigation(
    [
        st.Page(
            "pages/01_market.py",
            title="What does a night in London cost?",
            icon="🏠",
        ),
        st.Page(
            "pages/02_drilldown.py",
            title="Which neighbourhoods drive the premium?",
            icon="📍",
        ),
        st.Page(
            "pages/03_demand.py",
            title="Where is guest demand strongest?",
            icon="📊",
        ),
    ]
)
pg.run()
